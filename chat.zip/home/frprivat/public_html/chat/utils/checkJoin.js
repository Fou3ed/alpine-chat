import { socketIds } from "../models/connection/connectionEvents";

export async function checkJoin (userIds){
//send to admin socketId


}